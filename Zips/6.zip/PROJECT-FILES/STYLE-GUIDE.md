# Colors

- Background Dark Gray - #262529
- Gold - #FFC700
- Pink - #EA346F
- Progress Bar Gray - #4D4C53
- Button color - #333139

# Fonts

- Source Sans Pro - https://fonts.google.com/specimen/Source+Sans+Pro
