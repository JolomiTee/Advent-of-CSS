# Typography

- Oswald - https://fonts.google.com/specimen/Oswald?query=oswald
- Roboto - https://fonts.google.com/specimen/Roboto

# Colors

- Background color - #FBFBFB
- Pink - #F40082
- Yellow - #FFD200
