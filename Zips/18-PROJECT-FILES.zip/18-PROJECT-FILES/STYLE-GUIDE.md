# Fonts

- Roboto Mono - https://fonts.google.com/specimen/Roboto+Mono
- Roboto - https://fonts.google.com/specimen/Roboto

# Colors

- Background color: #F1F7F4
- Text color: #31292F
- Input Range Knob Color - #56858A
- Input Range Background - #CEDFE1
