# Fonts

- Inter - https://fonts.google.com/specimen/Inter

# Colors

- Primary (blue) - #1400FF
- Light Gray - #D4D4D4
- Dark Gray (icons) - #757575
- Errors (red) - #FF0000
- Success (green) - #5FA12B
