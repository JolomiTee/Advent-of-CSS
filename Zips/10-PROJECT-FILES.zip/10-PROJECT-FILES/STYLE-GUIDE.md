# Typography

- Source Sans Pro - https://fonts.google.com/specimen/Source+Sans+Pro

# Colors

- Page background color: #E3E9F9
- Text Input Color: #6778E8
- Text Input Background: #F0F3FA
- Button linear gradient: `linear-gradient(93.32deg, #8D9EFF -10.93%, #A674FB 113.82%);`
