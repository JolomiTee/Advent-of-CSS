# TYPOGRAPHY

- Roboto Mono - https://fonts.google.com/specimen/Roboto+Mono
- Inter - https://fonts.google.com/specimen/Inter?query=Inter

# COLORS

- background color: #F6F6F3
- background color for the bottom part of the card: #F7F7F7
- border separating tip amount: #DEDEDE
- vertical border separating bill amount and the number of people: #DEDEDE
- dashed border, for text input fields: #B3B3B3
- background color behind tip percentages: #EEEEEE
- top and bottom border, for tip percentage section: #DEDEDE
- percentage text: #60C1B6
- button color: #ED7861
