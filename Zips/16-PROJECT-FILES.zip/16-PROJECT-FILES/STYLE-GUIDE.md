# Colors

- Yellow - #FFD200
- Gray - #808080
