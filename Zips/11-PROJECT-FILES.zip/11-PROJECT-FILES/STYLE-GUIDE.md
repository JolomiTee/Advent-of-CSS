# Fonts

- Open Sans - https://fonts.google.com/specimen/Open+Sans

# Color

- Answer background color, yellow - #FFDD00
- Answer background color, light gray - #F0F0F0
