# Colors

- Yellow, Gold #FFB800

# Fonts

- Roboto Mono - https://fonts.google.com/specimen/Roboto+Monos
