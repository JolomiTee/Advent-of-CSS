# Typography

- Krona One -
- Oswald -

# Colors

- Page background color: #E9F5FA
- Day of the week and Date Text: #4DB0D3

## Cloudy

- Background: #4DB0D3
- Temperature Text: #E6DF95
- Content Text: #D3EBF4

## Sunny

- Background #E6DF95
- Temperature Text: #4DB0D3
- Content Text: #247490

## Stormy

- Background #0E2E3A
- Temperature Text: #E6DF95
- Content Text: #D3EBF4

## Snowy

- Background #BCE1EF
- Temperature Text: #0E2E3A
- Content Text: #247490

## Rainy

- Background #4DB0D3
- Temperature Text: #E6DF95
- Content Text: #D3EBF4

## Partly Cloudy

- Background #2B8BAD;
- Temperature Text: #E6DF95
- Content Text: #D3EBF4
